<template>
  <section class="bg-white text-gray-800">
    <header class="flex items-start gap-4 p-10 md:gap-8 md:py-12 md:px-20">
      <img
        src="../assets/amex-logo.png"
        class="h-20 w-16 md:h-[108px] md:w-24"
        alt="american express logo"
      />
      <h1
        class="text-xl md:text-3xl max-w-2.5 uppercase text-[#071658] font-extrabold"
      >
        Global Business Travel
      </h1>
    </header>
    <article
      class="bg-[#E8EFFA] flex p-10 gap-6 flex-col-reverse md:flex-row md:px-24 md:py-8"
    >
      <div
        class="flex flex-col flex-1 justify-around items-start text-3xl md:text-5xl w-full"
      >
        <div>
          <p class="mt-2 font-extrabold text-[#071658]">Simplify Your</p>
          <p class="mt-2 font-extrabold text-[#2F6DC9]">Travel Policy</p>
          <p class="mt-2 font-extrabold text-[#2F6DC9]">Management</p>
        </div>
        <p class="mt-4 text-[#071658] text-xl md:text-3xl">
          Effortlessly align every Category and Subcategory of your travel
          policy with industry standards and your business goals.
        </p>
      </div>
      <img
        src="../assets/man-with-bag.png"
        class="w-full md:w-[45%] flex-1 rounded-l-full rounded-r-full"
        alt="american express logo"
      />
    </article>
    <article
      aria-labelledby="benefits-heading"
      class="bg-[#071658] text-[#ffff] flex flex-col md:flex-row p-10 gap-6 md:pl-24 md:pr-6 md:py-8"
    >
      <div class="flex-1">
        <h2 id="benefits-heading" class="text-2xl font-bold mb-4">
          What You’ll Gain
        </h2>
        <div class="flex gap-6 flex-row space-y-2">
          <span class="border-[0.5px] mt-2 border-white"></span>
          <ul class="list-disc list-inside">
            <li class="list-inside">
              Automated extraction of policy content for all categories and
              subcategories
            </li>
            <li>AmexGBT global standards</li>
            <li>Scoring your policy content for clarity and compliance</li>
            <li>Detailed gap analysis reports</li>
            <li>
              Recommended policy generation or design your policy with your
              inputs
            </li>
            <li>Feedback options to capture your inputs</li>
            <li>Redesign policy that aligns your business goals</li>
          </ul>
        </div>
      </div>
      <div class="flex-1 flex flex-col justify-between gap-8">
        <h2 id="workflow-heading" class="text-2xl font-bold mb-4 text-center">
          How It Works
        </h2>
        <ol
          class="list-decimal list-inside gap-8 grid grid-cols-2 md:grid-cols-4 justify-between"
        >
          <li
            class="h-40 w-32 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4"
          >
            <span
              class="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#2F6DC9] text-white w-8 h-8 flex items-center justify-center rounded-full"
            >
              1
            </span>
            <img src="../assets/file.png" class="h-10 w-10" alt="file" />

            Upload your policy
          </li>
          <li
            class="h-40 w-32 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4"
          >
            <span
              class="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#2F6DC9] text-white w-8 h-8 flex items-center justify-center rounded-full"
            >
              1
            </span>
            <img src="../assets/search.png" class="h-10 w-10" alt="file" />

            Analyse benchmarking
          </li>
          <li
            class="h-40 w-32 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4"
          >
            <span
              class="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#2F6DC9] text-white w-8 h-8 flex items-center justify-center rounded-full"
            >
              1
            </span>
            <img src="../assets/message.png" class="h-10 w-10" alt="file" />
            Provide your feedback
          </li>
          <li
            class="h-40 w-32 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4"
          >
            <span
              class="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#2F6DC9] text-white w-8 h-8 flex items-center justify-center rounded-full"
            >
              1
            </span>
            <img src="../assets/file.png" class="h-10 w-10" alt="file" />

            Submit to redesign new policy
          </li>
        </ol>
      </div>
    </article>

    <article
      class="bg-[#2F6DC9] text-[#ffff] flex p-10 gap-6 md:pl-24 md:pr-6 md:pt-8 md:pb-32 flex-col md:gap-10 items-center justify-center"
      aria-labelledby="workflow-heading"
    >
      <h2 id="workflow-heading" class="text-2xl font-bold">
        Ready to benchmark your travel policy?
      </h2>
      <div class="flex flex-col md:flex-row gap-8">
        <select class="p-4 bg-white text-[#071658] min-w-[300px] rounded-md">
          <option class="p-4 bg-white text-[#071658]">hello</option>
          <option class="p-4 bg-white text-[#071658]">hello 1</option>
          <option class="p-4 bg-white text-[#071658]">hello 2</option>
        </select>
        <button
          class="flex p-4 gap-6 bg-amber-400 text-center rounded-md min-w-[300px]"
        >
          <img src="../assets/file.png" class="h-8 w-8" alt="file" />
          <h2 class="text-[#000] font-extrabold text-center text-xl">
            Upload Policy (PDF)
          </h2>
        </button>
      </div>
    </article>
  </section>
</template>

<script>
export default {
  name: "TravelPolicy",
};
</script>

<style scoped>
select {
  /* -webkit-appearance: none; */
  /* appearance: none;
    border: none; */
  padding-right: 1rem;
}
/* Tailwind handles most styling; scoped styles can be added if needed */
</style>
