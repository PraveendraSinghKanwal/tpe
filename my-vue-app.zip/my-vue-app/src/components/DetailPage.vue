<template>
  <section class="bg-white text-gray-800">
    <header class="flex items-start gap-4 p-2 md:gap-8 md:py-4 md:px-20">
      <img
        src="../assets/gbt-logo.png"
        class="h-16"
        alt="american express logo"
      />
    </header>
    <article
      class="bg-[#E8EFFA] flex flex-col justify-between p-10 gap-6 md:flex-row md:px-24 md:py-8"
    >
      <div
        class="flex flex-col justify-around items-start text-3xl md:text-5xl w-full md:w-[50%]"
      >
        <div>
          <p class="mt-2 font-bold text-[#071658]">Your BenchMarking</p>
          <p class="mt-2 font-bold text-[#071658]">Result</p>
        </div>
        <p class="mt-4 text-[#071658] text-[24px] md:text-xl">
          See how your travel policy performs across all Categories.
        </p>
        <div
          class="rounded-xl h-[60%] w-full bg-[#071658] mt-16 flex items-center flex-col md:flex-row text-2xl md:text-4xl justify-around text-white font-extrabold p-4"
        >
          <div class="p-4 bg-[#071658] flex justify-center">
            <div class="relative w-32 h-32 rounded-full bg-[#071658]">
              <div
                class="absolute inset-0 rounded-full border-2 border-white"
                style="background: conic-gradient(#2f6dc9 60%, #e5e7eb 0)"
              ></div>
              <div
                class="absolute inset-3 flex items-center justify-center border-2 border-white rounded-full bg-[#071658]"
              >
                <span class="font-semibold">60%</span>
              </div>
            </div>
          </div>
          <div class="w-[60%] text-center">OverAll Policy Coverage</div>
        </div>
      </div>
      <div
        class="flex justify-between flex-col gap-4 items-center w-full md:w-[50%] py-4 md:py-8"
      >
        <button
          class="flex p-4 gap-6 bg-amber-400 text-center rounded-md w-full md:w-[65%]"
        >
          <img
            src="../assets/graph.png"
            class="h-8 w-8 md:h-12 md:w-12 bg-white rounded-md p-2"
            alt="file"
          />
          <h2
            class="text-[#000] font-extrabold flex items-center text-md md:text-xl"
          >
            Download Full Report
          </h2>
        </button>
        <img
          src="../assets/laptop-2.png"
          class="h-auto w-65 object-fill"
          alt="american express logo"
        />
      </div>
    </article>
    <article
      aria-labelledby="benefits-heading"
      class="bg-[#071658] text-[#ffff] flex flex-col md:flex-row p-10 gap-6 md:p-24 md:py-16"
    >
      <ol
        class="list-decimal list-inside gap-4 md:gap-12 grid grid-cols-2 md:grid-cols-5 justify-between"
      >
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
        <li
          class="grid-cols-1 bg-[#E8EFFA] text-black rounded-2xl relative flex flex-col items-center text-center justify-around text-sm font-medium p-4 gap-6"
        >
          <h5 class="text-[#071658] text-xl font-normal text-center">
            Overview & Guidelines
          </h5>
          <h2 class="text-[#071658] text-4xl font-extrabold">65%</h2>
          <button class="px-4 mb-4 py-2 rounded-full bg-[#2F6DC9] text-white">
            Learn more
          </button>
        </li>
      </ol>
    </article>

    <article
      class="bg-white text-[#071658] flex p-10 gap-6 md:pl-24 md:pr-6 md:pt-8 md:pb-32 flex-col md:gap-8 items-left justify-left"
      aria-labelledby="workflow-heading"
    >
      <h2 id="workflow-heading" class="text-2xl font-bold text-[#2F6DC9]">
        Overview and Guidance
      </h2>
      <h3 class="text-xl">
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolor minus
        facilis laborum porro distinctio, alias veniam sint sit dolores atque at
        sed autem qui quibusdam fugiat, ea, ipsum nobis ex. Lorem, ipsum dolor
        sit amet consectetur adipisicing elit. Dolor minus facilis laborum porro
        distinctio, alias veniam sint sit dolores atque at sed autem qui
        quibusdam fugiat, ea, ipsum nobis ex. Lorem, ipsum dolor sit amet
        consectetur adipisicing elit. Dolor minus facilis laborum porro
        distinctio, alias veniam sint sit dolores atque at sed autem qui
        quibusdam fugiat, ea, ipsum nobis ex. Lorem, ipsum dolor sit amet
        consectetur adipisicing elit. Dolor minus facilis laborum porro
        distinctio, alias veniam sint sit dolores atque at sed autem qui
        quibusdam fugiat, ea, ipsum nobis ex.
      </h3>
    </article>
  </section>
</template>

<script>
export default {
  name: "TravelPolicy",
};
</script>

<style scoped>
/* Tailwind handles most styling; scoped styles can be added if needed */
</style>
